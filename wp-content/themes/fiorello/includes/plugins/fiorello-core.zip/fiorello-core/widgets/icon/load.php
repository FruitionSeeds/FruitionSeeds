<?php

include_once FIORELLO_CORE_ABS_PATH . '/widgets/icon/functions.php';
include_once FIORELLO_CORE_ABS_PATH . '/widgets/icon/icon.php';