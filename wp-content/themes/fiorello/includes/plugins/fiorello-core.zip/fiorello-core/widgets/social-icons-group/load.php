<?php

include_once FIORELLO_CORE_ABS_PATH . '/widgets/social-icons-group/functions.php';
include_once FIORELLO_CORE_ABS_PATH . '/widgets/social-icons-group/social-icons-group.php';