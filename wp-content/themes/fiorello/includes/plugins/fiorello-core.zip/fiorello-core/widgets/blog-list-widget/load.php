<?php

include_once FIORELLO_CORE_ABS_PATH . '/widgets/blog-list-widget/functions.php';
include_once FIORELLO_CORE_ABS_PATH . '/widgets/blog-list-widget/blog-list.php';