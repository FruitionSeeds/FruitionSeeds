<?php

include_once FIORELLO_CORE_ABS_PATH . '/widgets/custom-font/functions.php';
include_once FIORELLO_CORE_ABS_PATH . '/widgets/custom-font/custom-font.php';