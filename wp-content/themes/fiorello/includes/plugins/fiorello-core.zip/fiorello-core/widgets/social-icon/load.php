<?php

include_once FIORELLO_CORE_ABS_PATH . '/widgets/social-icon/functions.php';
include_once FIORELLO_CORE_ABS_PATH . '/widgets/social-icon/social-icon.php';