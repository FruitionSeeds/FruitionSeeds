<?php

include_once FIORELLO_CORE_SHORTCODES_PATH . '/text-marquee/functions.php';
include_once FIORELLO_CORE_SHORTCODES_PATH . '/text-marquee/text-marquee.php';