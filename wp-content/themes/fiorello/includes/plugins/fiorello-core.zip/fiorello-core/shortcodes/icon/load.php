<?php

include_once FIORELLO_CORE_SHORTCODES_PATH . '/icon/functions.php';
include_once FIORELLO_CORE_SHORTCODES_PATH . '/icon/icon.php';