<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Empty_space
 */
class WPBakeryShortCode_Vc_Empty_Space extends WPBakeryShortCode {
}
