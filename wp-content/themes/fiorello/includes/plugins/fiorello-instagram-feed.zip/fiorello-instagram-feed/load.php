<?php

include_once 'lib/fiorello-instagram-api.php';
include_once 'widgets/load.php';